% 
% ISEL - Instituto Superior de Engenharia de Lisboa.
% 
% LEIC - Licenciatura em Engenharia Informatica e de Computadores.
%
% Com  - Comunica��es. 
%
% bit2file.m 
%
%
% Recebe:   bitstream, vetor no qual cada posi��o � um bit.
%           filename, nome do ficheiro destino.
% Retorna:  x, ficheiro na forma de vetor
%
function  x = bit2file( bitstream, filename )

% Criar o vetor com elementos do tipo inteiro a 8 bit.
x = uint8( zeros(1, length(bitstream) / 8 ) );

% vetor com as potencias de 2.
p2 = 2.^(7:-1:0);

% Calcular ponto a ponto.
k = 1;
for i=1: length(x)
    x(i) = bitstream( k:k+7 ) * p2';
    k = k + 8;
end

% Passar para ficheiro.
vector2file(x, filename);
return;



%
%
%
function vector2file(x, filename)

% Open file.
fid = fopen( filename, 'wb' );

% Check descriptor.
if -1==fid
    error( sprintf('Error opening file %s for writing ',filename) );
end

% Write the vetor.
fwrite( fid, x, 'uchar' );

% Close file.
fclose( fid );

return;

